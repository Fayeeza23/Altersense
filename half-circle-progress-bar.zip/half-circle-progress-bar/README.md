# Half Circle progress baR

A Pen created on CodePen.io. Original URL: [https://codepen.io/fayeeza23/pen/zYjxjwK](https://codepen.io/fayeeza23/pen/zYjxjwK).

